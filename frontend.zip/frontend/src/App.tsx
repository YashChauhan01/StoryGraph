import React from "react";
import { ManuscriptEditor } from "./components/ManuscriptEditor";
import { EntitySidebar } from "./components/EntitySidebar";
import "./index.css";

/**
 * Main Application Shell
 * Currently defaults to 'test-manuscript' for rapid local development.
 */
function App() {
  // In a future update, this can be pulled from a URL parameter using react-router
  const manuscriptId = "test-manuscript";

  return (
    <div className="flex h-screen w-full bg-white overflow-hidden">
      {/* Main Content Area: 
          Contains the editor. It flexes to fill available space.
      */}
      <main className="flex-1 h-full overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto">
          <ManuscriptEditor manuscriptId={manuscriptId} />
        </div>
      </main>

      {/* Sidebar Area: 
          Fixed width, provides structured metadata extracted by the AI.
      */}
      <aside className="w-80 h-full border-l border-gray-200 bg-gray-50 shadow-sm">
        <EntitySidebar />
      </aside>
    </div>
  );
}

export default App;