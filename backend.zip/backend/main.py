import sys
import asyncio
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from starlette.websockets import WebSocketState

# Add current path to sys.path to find services
sys.path.insert(0, str(Path(__file__).parent))

# IMPORT THE SINGLETON INSTANCES
from services.text_processor import processor as text_streamer
from services.story_processor import processor as story_logic

load_dotenv(Path(__file__).parent / ".env")

app = FastAPI()

app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True, 
    allow_methods=["*"], allow_headers=["*"]
)

# --- WORKER ---
async def extraction_worker():
    print("⚙️ Worker: Online and listening to queue...")
    while True:
        # Pull from the SINGLETON queue
        job = await text_streamer.processing_queue.get()
        websocket, text, metadata = job['websocket'], job['text'], job['metadata']
        
        try:
            if websocket.client_state == WebSocketState.CONNECTED:
                # Call the SINGLETON logic
                result = await story_logic.process_paragraph(text, metadata)
                
                # Send JSON
                await websocket.send_json({
                    "type": "entities_extracted",
                    "data": result # Contains 'entities_extracted' key
                })
                print(f"🚀 Sent results for Paragraph {metadata.get('paragraph')}")
        except Exception as e:
            print(f"❌ Worker Error: {e}")
        finally:
            text_streamer.processing_queue.task_done()

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(extraction_worker())

# --- WEBSOCKET ---
@app.websocket("/ws/manuscript/{manuscript_id}")
async def websocket_endpoint(websocket: WebSocket, manuscript_id: str):
    await websocket.accept()
    print(f"✓ Connected: {manuscript_id}")
    try:
        while True:
            data = await websocket.receive_json()
            # Push to the SINGLETON queue
            await text_streamer.add_to_stream(
                websocket, 
                data.get('text', ''), 
                {"manuscript_id": manuscript_id, "paragraph": data.get('paragraph', 0)}
            )
    except WebSocketDisconnect:
        print(f"Disconnected: {manuscript_id}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)